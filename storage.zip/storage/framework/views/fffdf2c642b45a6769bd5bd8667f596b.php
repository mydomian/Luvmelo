employee login
<?php /**PATH C:\xampp\htdocs\Luvmelo\resources\views/employee/pages/login.blade.php ENDPATH**/ ?>