<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="table-tr-border">
            <td class="custom-paragraph-color"><?php echo e($employee->name); ?></td>
            <td class="custom-number-color"><?php echo e(employeeSlotCount($employee->id)); ?></td>
            <td class="custom-paragraph-color"><?php echo e($employee->phone); ?></td>
            <td class="text-primary"><?php echo e($employee->email); ?></td>
            <td class="text-primary"><?php echo e($employee->street); ?></td>
            <td class="text-primary"><?php echo e($employee->appartment); ?></td>
            <td class="text-primary"><?php echo e($employee->city); ?></td>
            <td class="text-primary"><?php echo e($employee->state); ?></td>
            <td class="text-primary"><?php echo e($employee->zip_code); ?></td>
            <td style="width:200px; display:flex; justify-content:center">
                <a href="<?php echo e(route('admin.create_avibility_employee',$employee->id)); ?>" class="request-button">Edit <i class="fas fa-edit"></i> </a>
                <button class="request-button ml-2">Request</button>
            </td>
        </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\Luvmelo\resources\views/admin/pages/employee/append/lists.blade.php ENDPATH**/ ?>