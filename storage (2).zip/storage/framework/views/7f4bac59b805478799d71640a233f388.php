<?php $__env->startPush('admin-css'); ?>
    <style>
        input[type="time"] {
            font-size: 11.5px; /* You can also use specific values like '12px', '0.8em', etc. */
        }
        input[type="time"]::-webkit-datetime-edit-ampm-field {
            display: none;
        }
        input[type="time"] {
            text-align: center;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('admin-content'); ?>
<div class="custom-name-color pt-3 overview-text" >
    Employee Avaibility Update
  </div>
  <div class="row home-main-section pb-5">
    <div class="col-md-12 mt-3 custom-paragraph-color">
        <div class="card">

                <div class="card-body">
                    <div class="row d-flex justify-content-center">
                        <div class="mt-3 text-dark text-center">General</div>
                        <div class="col-md-8 row employee-details-input mt-2">
                            <div class="col-md-4 my-2">Name
                                <div><input type="text" name="name" placeholder="Name" value="<?php echo e($employee->name); ?>" readonly></div>
                            </div>
                            <div class="col-md-4 my-2">Phone
                                <div><input type="text" name="phone" placeholder="Phone" value="<?php echo e($employee->phone); ?>" readonly></div>
                            </div>

                            <div class="col-md-4 my-2">Email
                                <div><input type="email" name="email" placeholder="Email" value="<?php echo e($employee->email); ?>" readonly></div>
                            </div>
                            <div class="col-md-4 my-2">Street
                                <div><input type="text" name="street" placeholder="Street" value="<?php echo e($employee->street); ?>" readonly></div>
                            </div>
                            <div class="col-md-4 my-2">Apt / Suite / Unit
                                <div><input type="text" name="appartment" value="<?php echo e($employee->appartment); ?>" placeholder="Apt / Suite / Unit" readonly></div>
                            </div>
                            <div class="col-md-4 my-2">
                            </div>
                            <div class="col-md-4 my-2">City
                                <div><input type="text" name="city" value="<?php echo e($employee->city); ?>" placeholder="City" readonly></div>
                            </div>
                            <div class="col-md-4 my-2">State
                                <div><input type="text" name="state" value="<?php echo e($employee->state); ?>" placeholder="State" readonly></div>
                            </div>

                            <div class="col-md-4 my-2">Zipcode
                                    <div><input type="text" name="zipcode" value="<?php echo e($employee->zip_code); ?>" placeholder="Zipcode" readonly></div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="d-flex justify-content-between">
                            <div class="text-dark">Availability <span class="text-warning">(Add 10 sessions total)</span></div>
                            <div>
                                <?php if($employee->status == 'active'): ?>
                                    <a href="<?php echo e(route('admin.employeeStatus',['employee'=>$employee->id,'status'=>'inactive'])); ?>" class="btn btn-sm btn-danger">Inactive</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('admin.employeeStatus',['employee'=>$employee->id,'status'=>'active'])); ?>" class="btn btn-sm btn-success">Active</a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php $__currentLoopData = $avaEmps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$avaEmp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-custom-14 row  mt-3">
                                <form action="<?php echo e(route('admin.create_avibility_employee',$employee->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group form-check ">
                                        <input type="checkbox" name="day" class="form-check-input" <?php if(dayCheck($employee->id, $key) == 'check'): ?> checked <?php endif; ?> value="<?php echo e($key); ?>" id="<?php echo e($key); ?>">
                                        <label class="form-check-label" style="font-size:13px;" for="<?php echo e($key); ?>"><?php echo e($key); ?></label>
                                    </div>
                                    <div class="col-md-12 row employee-details-by-day mt-1  ">
                                        <div class="col-md-12 m-1 row mp0 text-center">
                                            <div class="col-md-6 f10 media-quary-width-40">Start</div>
                                            <div class="col-md-6 f10 media-quary-width-40 media-margin-left-4">End</div>
                                        </div>

                                        <?php $__currentLoopData = $avaEmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-12 m-1 mp0 row employee-details-input-small">
                                                <input type="time" name="start_time[]" value="<?php echo e($item->start_time); ?>" class="col-md-6 mp0 media-quary-width-40">
                                                <input type="time" name="out_time[]" value="<?php echo e($item->out_time); ?>" class="col-md-6 mp0 media-quary-width-40 ">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="col-md-12 m-1 row custom-paragraph-color mt-2 mb-3 text-center">
                                        <button class="request-button-employee-view-update">Update</button>
                                    </div>
                                </form>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class="d-flex justify-content-center mt-5">
                        <a href="<?php echo e(route('admin-employees.index')); ?>" class="btn btn-sm btn-info">Finish -> go to employee lists</a>
                    </div>
                </div>


        </div>
    </div>

  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Luvmelo\resources\views/admin/pages/employee/create_avibility_employee.blade.php ENDPATH**/ ?>